#include<iostream>
using namespace std;

int main() 
{
	int x,g;
	cin>> x>>g;
	if (x>=10||g>=20)
 	{
 		cout<<"1";
	 }
	else
	{
		cout<<"0";
	}
}
