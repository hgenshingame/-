#include <iostream>
#include <cmath>
#include <cstdio>
using namespace std;

int main()
{
	char a;
	cin>>a;
	
	if (a%2 !=0)
	   cout<<"YES"; 
	else{
	   cout<<"NO";
	}
}
