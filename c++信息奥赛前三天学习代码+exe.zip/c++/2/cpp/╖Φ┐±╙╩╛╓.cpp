#include<iostream>
#include<cstdio>
using namespace std;
char j;
int k,m,n;
int main ()
{   

	cin>>k>>j;
	
	if (k<1000)
	{
		n=k-1000;
		if (j=='y'){}
		else
		{ } 
		
	}
    else
    {
    	if (j=='y'){m=8+5 ;}
    	else{m=8 ;}
	}
	
	
	
	
	cout<<m;
	return 0;
}
