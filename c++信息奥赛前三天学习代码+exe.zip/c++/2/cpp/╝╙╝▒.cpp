#include<iostream>
#include<cstdio>
using namespace std;

int main ()
{   
	char j;
	int k,m;
	cin>>k>>j;
	
	if (k>1000&& j=='y')
	{
		m=8+5;
	}
	
	
	
	
	
	cout<<m;
	return 0;
}
