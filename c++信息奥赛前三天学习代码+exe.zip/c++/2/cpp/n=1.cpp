#include <iostream>
#include<cmath>
#include<cstdio>
using namespace std;

int main ()
{
	double n;
	cin>>n;
	
	if (n>0)
	{
		cout<<"positive";
	}
    if (n<0)
    {
    	cout<<"negative";
	}
    if (n==0)
    {
    	cout<<"zero";
	}
}

