#include <iostream>
#include<cmath>
#include <cstdio>
using namespace std;

int main()
{
	double a;
	cin>>a;
	a = fabs(a);
	printf("%0.2f\n",a);
}
