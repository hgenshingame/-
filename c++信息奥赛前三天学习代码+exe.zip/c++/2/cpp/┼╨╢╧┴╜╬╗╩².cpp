#include<iostream>
using namespace std;

int main()
{
	int a;
	cin >>a;
	
	if (a>=10&&a<=99)
	  cout << "1";
	else
	  cout<< "0";
}
