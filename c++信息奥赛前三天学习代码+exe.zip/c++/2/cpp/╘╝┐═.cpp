#include<iostream>
using namespace std;

int main()
{
	int a;
	cin>>a;
	
	switch(a){
		case 1 : cout<<"NO";break;
		case 2 : cout<<"YES";break;
		case 3 : cout<<"NO";break;
		case 4 : cout<<"YES";break;
		case 5 : cout<<"NO";break;
		case 6 : cout<<"YES";break;
		case 7 : cout<<"YES";break;

	}
}
