#include<iostream>
using namespace std;

int main()
{
	int a,a1,a2,a3;
	cin>> a;
	
	if (a%3==0)
	{
		a=a/3 ;
		if (a%5==0&&a%7!=0)
		{
			a1 = a/5;
			if (a1%7==0)
			{cout<<"3,5,7";}
			if (a1%7!=0)
			{cout<<"3,5";} 
		}
		if (a%7==0&&a%5!=0)
		{
			cout<<"3,7";
		}
		if (a%5!=0&&a%7!=0)
		{
			cout<<"3";
		}
	}
	
	if (a%5==0)
	{
		a=a/5;
		if (a%7==0)
		{
			if (a%3==0)
			{cout<<"3,5,7";}
			if (a%3!=0)
			{cout<<"5,7";} 
		}
		if (a%7!=0&&a%3==0)
		{
			cout<<"3,5";
		}
		if (a%3!=0&&a%7!=0)
		{
			cout<<"5";
		}
	}
	
	if (a%7==0)
	{
		a=a/7 ;
		if (a%5==0)
		{
			if (a%3==0)
			{cout<<"3,5,7";}
			if (a%3!=0)
			{cout<<"3,5";} 
		}
		if (a%3==0&&a%5!=0)
		{
			cout<<"3,7";
		}
		if (a%5!=0&&a%3!=0)
		{
			cout<<"7";
		}
	}
	else 
		cout<<"n";
	
return 0; 
} 
