#include<iostream>
using namespace std;

int main()
{
	const double PI=3.1415926 ;
	double r,s,h,v;
	cout<<"�뾶";
	cin>>r;
	cout<<"��";
	cin >>h;
	
	s=PI*r*r;
	v=s*h;
	
	cout<<v; 

	return 0;
}
