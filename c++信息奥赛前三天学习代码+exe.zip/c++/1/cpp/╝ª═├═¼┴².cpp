#include<iostream>
using namespace std;

int main()
{
	int h,f,t,j;
	cout<<"ͷ����";
	cin>>h;
    cout<<"������";
    cin>>f;
	
	j=(h*4-f)/2;
	t=30-j;
	cout<<j<<" " <<t;

	return 0;
}
