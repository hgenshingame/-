#include<iostream>
using namespace std;

int main()
{
	double a,b,c,p,j;
	cout<<"first ";
	cin>>a;
	cout<<"second ";
	cin>>b;
	cout<<"third ";
	cin>>c;
	
	p=(a+b+c)/3;
	j=a*b*c;
	
	cout<<p<<" "<<j;
	return 0; 
}
