#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	float h,x=0,a=1;
	int s;
	for(s=1;s<=100;s++)
	{
		if(s%2!=0)
		{
			h=a/s;
			
			x=x+h;
		}
		else
		{
			h=a/s;
			x=x-h;
		}
	}
	cout<<x<<endl;
	return 0;
}

