#include<iostream>
using namespace std;

int main(){
 	int n=5,zao=1;
	for (int i=n-1;i>=1;i--)
	    zao=(zao+1)*2;
	cout<<zao;	
}
