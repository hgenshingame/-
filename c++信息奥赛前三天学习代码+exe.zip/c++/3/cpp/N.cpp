#include<iostream>
using namespace std;

int main()
{
	int a,n,b;
	cin>>n;
	for(a=1;a<n;++a)
	   n=a*n;
	
    cout<<n;
}
